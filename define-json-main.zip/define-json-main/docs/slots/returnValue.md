

# Slot: returnValue 


_Return value details_





URI: [odm:slot/returnValue](https://cdisc.org/odm2/slot/returnValue)
Alias: returnValue

<!-- no inheritance hierarchy -->





## Applicable Classes

| Name | Description | Modifies Slot |
| --- | --- | --- |
| [FormalExpression](../classes/FormalExpression.md) | A computational element that defines the execution of a data derivation within a specific context |  no  |






## Properties

* Range: [ReturnValue](../classes/ReturnValue.md)




## Identifier and Mapping Information






### Schema Source


* from schema: https://cdisc.org/define-json




## Mappings

| Mapping Type | Mapped Value |
| ---  | ---  |
| self | odm:returnValue |
| native | odm:returnValue |




## LinkML Source

<details>
```yaml
name: returnValue
description: Return value details
from_schema: https://cdisc.org/define-json
rank: 1000
alias: returnValue
owner: FormalExpression
domain_of:
- FormalExpression
range: ReturnValue

```
</details>