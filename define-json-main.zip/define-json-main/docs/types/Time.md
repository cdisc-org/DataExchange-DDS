# Type: Time 




_A time object represents a (local) time of day, independent of any particular day_



URI: [xsd:time](http://www.w3.org/2001/XMLSchema#time)

* [base](https://w3id.org/linkml/base): XSDTime

* [uri](https://w3id.org/linkml/uri): xsd:time

* [repr](https://w3id.org/linkml/repr): str







## Identifier and Mapping Information






### Schema Source


* from schema: https://cdisc.org/define-json




## Mappings

| Mapping Type | Mapped Value |
| ---  | ---  |
| self | xsd:time |
| native | odm:time |
| exact | schema:Time |


